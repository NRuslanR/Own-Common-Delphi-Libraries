// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Smexportd2006.pas' rev: 10.00

#ifndef Smexportd2006HPP
#define Smexportd2006HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Smereg.hpp>	// Pascal unit
#include <Excnst.hpp>	// Pascal unit
#include <Exportds.hpp>	// Pascal unit
#include <Smestat.hpp>	// Pascal unit
#include <Sme2bde.hpp>	// Pascal unit
#include <Sme2ole.hpp>	// Pascal unit
#include <Smewiz.hpp>	// Pascal unit
#include <Sme2xls.hpp>	// Pascal unit
#include <Sme2sylk.hpp>	// Pascal unit
#include <Sme2dif.hpp>	// Pascal unit
#include <Sme2wks.hpp>	// Pascal unit
#include <Sme2wq.hpp>	// Pascal unit
#include <Sme2sql.hpp>	// Pascal unit
#include <Sme2xml.hpp>	// Pascal unit
#include <Sme2clp.hpp>	// Pascal unit
#include <Sme2ds.hpp>	// Pascal unit
#include <Sme2txt.hpp>	// Pascal unit
#include <Sme2html.hpp>	// Pascal unit
#include <Sme2cell.hpp>	// Pascal unit
#include <Sme2rtf.hpp>	// Pascal unit
#include <Smesave.hpp>	// Pascal unit
#include <Smespecs.hpp>	// Pascal unit
#include <Smemime.hpp>	// Pascal unit
#include <Sme2spss.hpp>	// Pascal unit
#include <Sme2pump.hpp>	// Pascal unit
#include <Sme2pdf.hpp>	// Pascal unit
#include <Sme2pumpado.hpp>	// Pascal unit
#include <Sme2pumpbde.hpp>	// Pascal unit
#include <Sme2pumpibx.hpp>	// Pascal unit
#include <Sme2pumpmdb.hpp>	// Pascal unit
#include <Sme2pumpdoa.hpp>	// Pascal unit
#include <Smeengine.hpp>	// Pascal unit
#include <Smeengww.hpp>	// Pascal unit
#include <Smeengstrings.hpp>	// Pascal unit
#include <Smeengsg.hpp>	// Pascal unit
#include <Smeengdb.hpp>	// Pascal unit
#include <Smeengdoa.hpp>	// Pascal unit
#include <Smeenglv.hpp>	// Pascal unit
#include <Sme2ldif.hpp>	// Pascal unit
#include <Smeengdx.hpp>	// Pascal unit
#include <Smeengdc.hpp>	// Pascal unit
#include <Smeengibo.hpp>	// Pascal unit
#include <Sme2dbf.hpp>	// Pascal unit
#include <Smeengcx.hpp>	// Pascal unit
#include <Smeutils.hpp>	// Pascal unit
#include <Smeengvg.hpp>	// Pascal unit
#include <Sme2ado.hpp>	// Pascal unit
#include <Smeengfxdc.hpp>	// Pascal unit
#include <Smeengrzlv.hpp>	// Pascal unit
#include <Smeengsm.hpp>	// Pascal unit
#include <Smeengeh.hpp>	// Pascal unit
#include <Smemonitor.hpp>	// Pascal unit
#include <Smezipfile.hpp>	// Pascal unit
#include <Sme2json.hpp>	// Pascal unit
#include <Smeactns.hpp>	// Pascal unit
#include <Sme2xlsx.hpp>	// Pascal unit
#include <Sme2docx.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Inifiles.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Multimon.hpp>	// Pascal unit
#include <Uxtheme.hpp>	// Pascal unit
#include <Themes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Actnlist.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Helpintfs.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <Flatsb.hpp>	// Pascal unit
#include <Graphutil.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Clipbrd.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Fmtbcd.hpp>	// Pascal unit
#include <Widestrings.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Extdlgs.hpp>	// Pascal unit
#include <Mapi.hpp>	// Pascal unit
#include <Extactns.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Dblogdlg.hpp>	// Pascal unit
#include <Dbpwdlg.hpp>	// Pascal unit
#include <Dbctrls.hpp>	// Pascal unit
#include <Appevnts.hpp>	// Pascal unit
#include <Axctrls.hpp>	// Pascal unit
#include <Olectrls.hpp>	// Pascal unit
#include <Checklst.hpp>	// Pascal unit
#include <Proxies.hpp>	// Pascal unit
#include <Idemessages.hpp>	// Pascal unit
#include <Captioneddocktree.hpp>	// Pascal unit
#include <Tabs.hpp>	// Pascal unit
#include <Docktabset.hpp>	// Pascal unit
#include <Percentagedocktree.hpp>	// Pascal unit
#include <Actnman.hpp>	// Pascal unit
#include <Actnmenus.hpp>	// Pascal unit
#include <Xpstyleactnctrls.hpp>	// Pascal unit
#include <Basedock.hpp>	// Pascal unit
#include <Deskutil.hpp>	// Pascal unit
#include <Deskform.hpp>	// Pascal unit
#include <Dockform.hpp>	// Pascal unit
#include <Msxmldom.hpp>	// Pascal unit
#include <Xmldom.hpp>	// Pascal unit
#include <Xmlintf.hpp>	// Pascal unit
#include <Toolsapi.hpp>	// Pascal unit
#include <Designeditors.hpp>	// Pascal unit
#include <Smeengsmi.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Smexportd2006
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Smexportd2006 */
using namespace Smexportd2006;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Smexportd2006
